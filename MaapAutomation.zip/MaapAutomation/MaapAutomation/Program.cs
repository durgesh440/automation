using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Remote;
using System.Threading;

using OpenQA.Selenium.Support.UI;
namespace MaapAutomation
{
    class Program
    {
        static void Main(string[] args)
        {
            // The code provided will print ‘Hello World’ to the console.
            // Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.
            //Console.WriteLine("Hello World!");
            //Console.ReadKey();


            //Create the reference for our browser
            IWebDriver driver = new ChromeDriver();

            //Navigate to google page
            driver.Navigate().GoToUrl("http:\\maap-dev.bcatoolkit.com");

            driver.Manage().Window.Maximize();
            System.Threading.Thread.Sleep(2000);

            IWebElement element = driver.FindElement(By.XPath("//*[@id='header']/div/div[2]/ul/li[3]/a"));
            element.Click();
            // this.driver.FindElement(By.XPath("//*[@id='header']/div/div[2]/ul/li[3]/a"));

            //Find the Search text box UI Element
            // IWebElement element = driver.FindElement(By.Name("q"));

            //Perform Ops
            //element.SendKeys("executeautomation");
           
            IWebElement FieldUserName = driver.FindElement(By.Id("txtUserName"));
            FieldUserName.SendKeys("basic");

            IWebElement FieldtxtPassword = driver.FindElement(By.XPath("//*[@id='ContentPlaceHolder1_txtPassword']"));
            FieldtxtPassword.SendKeys("basic");

            System.Threading.Thread.Sleep(2000);

            IWebElement btnSign = driver.FindElement(By.XPath("//*[@id='ContentPlaceHolder1_btnSignI1n']"));
            btnSign.Click();

            System.Threading.Thread.Sleep(6000);
            //Close the browser

            IWebElement FieldScenarioName = driver.FindElement(By.Id("txtScenarioName"));
            FieldScenarioName.SendKeys("MAA1903A");

            System.Threading.Thread.Sleep(3000);

            IWebElement btnSearch = driver.FindElement(By.Id("btnSearch"));
            btnSearch.Click();

            System.Threading.Thread.Sleep(4000);

            IWebElement btnValue = driver.FindElement(By.ClassName("getClassId"));
            btnValue.Click();

            System.Threading.Thread.Sleep(6000);

            IWebElement btnOutput = driver.FindElement(By.XPath("//*[@id='ancOutput']"));
            btnOutput.Click();

            System.Threading.Thread.Sleep(6000);


            IWebElement btnRunSCAP_CMAP = driver.FindElement(By.XPath("//*[@id='Button1']"));
            btnRunSCAP_CMAP.Click();

            System.Threading.Thread.Sleep(59000);

            //WaitForElementInvisible("loaderCMAP", driver);


            driver.Close();
            driver.Quit();
            
        }


        public static void WaitForElementInvisible(string ID, IWebDriver driver)
        {
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(10));
            wait.Until<bool>((d) =>
            {
                try
                {
                    IWebElement element = d.FindElement(By.ClassName(ID));
                    return !element.Displayed;
                }
                catch (NoSuchElementException)
                {
                    // If the find fails, the element exists, and
                    // by definition, cannot then be visible.
                    return true;
                }
            });
        }
    }
}
